Main.cpp - Normal matrix mult application
Main_omp.cpp - Normal matrix mult with OpenMP 
Main_papi.cpp - Normal matrix mult with PAPI interface calls
Main_omp_papi.cpp - Normal matrix mult with OpenMP including PAPI interface calls

RunTests.sh - Compile, Run, and record g++ and icpc for Main.cpp
RunOmpTests.sh - Compile, Run, and record g++ and icpc for Main_omp.cpp
RunPapiTests.sh - Compile, Run, and record g++ and icpc for Main_papi.cpp
RunOmpPapiTests.sh - Compile, Run, and record g++ and icpc for Main_omp_papi.cpp